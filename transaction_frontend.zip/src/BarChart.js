
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";

const BarChart = ({ month }) => {
  const [chartData, setChartData] = useState({});

  useEffect(() => {
    fetchBarChartData();
  }, [month]);

  const fetchBarChartData = async () => {
    try {
      const response = await axios.get(`/bar-chart?month=${month}`);
      const data = response.data;

      setChartData({
        labels: Object.keys(data),
        datasets: [
          {
            label: "Number of items",
            data: Object.values(data),
            backgroundColor: "rgba(75, 192, 192, 0.6)",
          },
        ],
      });
    } catch (error) {
      console.error("Error fetching bar chart data", error);
    }
  };

  return (
    <div>
      <h3>Price Range Bar Chart</h3>
      <Bar
        data={chartData}
        options={{
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        }}
      />
    </div>
  );
};

export default BarChart;
    