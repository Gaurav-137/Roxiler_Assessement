
import React, { useState, useEffect } from "react";
import axios from "axios";

const Statistics = ({ month }) => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchStatistics();
  }, [month]);

  const fetchStatistics = async () => {
    try {
      const response = await axios.get(`/statistics?month=${month}`);
      setStats(response.data);
    } catch (error) {
      console.error("Error fetching statistics", error);
    }
  };

  if (!stats) return <div>Loading...</div>;

  return (
    <div>
      <h3>Statistics</h3>
      <div>Total Sale Amount: {stats.total_sale_amount}</div>
      <div>Total Sold Items: {stats.total_sold_items}</div>
      <div>Total Not Sold Items: {stats.total_not_sold_items}</div>
    </div>
  );
};

export default Statistics;
    