
import React, { useState, useEffect } from "react";
import axios from "axios";

const TransactionTable = ({ month }) => {
  const [transactions, setTransactions] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchTransactions();
  }, [month, page]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `/transactions?month=${month}&search=${searchText}&page=${page}`
      );
      setTransactions(response.data.results);
    } catch (error) {
      console.error("Error fetching transactions", error);
    }
    setLoading(false);
  };

  const handleSearch = (e) => {
    setSearchText(e.target.value);
    setPage(1);
    fetchTransactions();
  };

  return (
    <div>
      <div>
        <input
          type="text"
          placeholder="Search transactions"
          value={searchText}
          onChange={handleSearch}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Sold</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction) => (
            <tr key={transaction.id}>
              <td>{transaction.title}</td>
              <td>{transaction.description}</td>
              <td>{transaction.price}</td>
              <td>{transaction.sold ? "Yes" : "No"}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div>
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>
          Previous
        </button>
        <button onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
};

export default TransactionTable;
    