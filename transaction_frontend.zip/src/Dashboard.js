
import React, { useState } from "react";
import TransactionTable from "./TransactionTable";
import Statistics from "./Statistics";
import BarChart from "./BarChart";

const Dashboard = () => {
  const [selectedMonth, setSelectedMonth] = useState("3");

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
  };

  return (
    <div>
      <h1>Transactions Dashboard</h1>

      <div>
        <label>Select Month:</label>
        <select value={selectedMonth} onChange={handleMonthChange}>
          <option value="1">January</option>
          <option value="2">February</option>
          <option value="3">March</option>
          <option value="4">April</option>
          <option value="5">May</option>
          <option value="6">June</option>
          <option value="7">July</option>
          <option value="8">August</option>
          <option value="9">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>
      </div>

      <TransactionTable month={selectedMonth} />
      <Statistics month={selectedMonth} />
      <BarChart month={selectedMonth} />
    </div>
  );
};

export default Dashboard;
    